﻿using UnityEngine;
using System.Collections;

public class ColorChange : MonoBehaviour
{

	Renderer r;

	// Use this for initialization
	void Start()
	{
		r = GetComponent<Renderer>();
	}

	// Update is called once per frame
	void Update()
	{

	}

	void OnCollisionEnter()
	{
		Debug.Log("Enter");
		r.material.color=new Color(255, 0, 0);
	}

	void OnCollisionExit()
	{
		r.material.color = new Color(0,0, 255);
	}
}
